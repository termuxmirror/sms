from setuptools import setup, find_packages

setup(
    name='sms',
    version='0.1',
    packages=find_packages(),
    install_requires=['pystyle', 'requests'],
    entry_points={
        'console_scripts': [
            'sms = sms.sms_sender:menu',
        ],
    },
    package_data={'sms': ['back/*']},
)
